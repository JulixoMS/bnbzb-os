#ifndef __KLIB
#define __KLIB
#include "kport.h"
#define START_MEM 0xBA000
#define ACTIVE    0x00
#define PASIVE    0x01
#define NULL      (void *)-1
char *vidptr = (char*)0xB8000;
unsigned int current_vga_pos = 0;
unsigned int ypos = 0;
unsigned char color = 0x00;
unsigned char trsp = 0;
typedef unsigned char uint8_t;
typedef char int8_t;
typedef int* intptr_t;
typedef void* fncptr_t;
typedef unsigned int* uintptr_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned long long size_t;
typedef uint8_t bool;
#include "malloc.h"

void setScrMode(uint8_t mode) {
	if (mode == ACTIVE) {
		vidptr = (char*)0xB8000;
	} else if (mode == PASIVE) {
		vidptr = (char*)0xB9000;
	}
}

void updateScr(void) {
	if ((uint32_t)vidptr == (uint32_t)0xB9000) {
		for (uint32_t i = 0xB8000; i < 0xB8FFF; i++) {
			*((uint8_t*)i) = *((uint8_t*)(i+0x01000));
		}
	}
}

size_t size(uint8_t *ptr) {
	size_t sz = 0;
	while (ptr[sz] != '\0') {
		sz++;
	}
	return size;
}

void cursor(unsigned int pos) {
		outb(0x3D4, 14);
		outb(0x3D5, ((pos >> 8) & 0x00FF));
		outb(0x3D4, 15);
		outb(0x3D5, pos & 0x00FF);
}

char *reverse(char *str) {
	char *res;
	uint32_t i = 0;
	uint32_t length = 0;
	while (str[length] != '\0') {
		length++;
	}
	for (i = 0; i < length; i++) {
		res[i] = str[(length-1)-i];
	}
	res[i+1] = '\0';
	return res;
}

char* itoa(int num, int base) {
	char *str = ""; 
	int i = 0; 
	uint8_t isNegative = 0; 
	if (num == 0) { 
		str[i++] = '0'; 
		str[i] = '\0'; 
		return str; 
	} 
	if (num < 0 && base == 10) { 
		isNegative = 1; 
		num = -num; 
	} 
	while (num != 0) { 
		int rem = num % base; 
		str[i++] = (rem > 9)? (rem-10) + 'a' : rem + '0'; 
		num = num/base; 
	} 
	if (isNegative == 1) 
		str[i++] = '-'; 
	str[i] = '\0';
	str = reverse(str);
	return str; 
} 


bool equals(char *a, char *b) {
	for (uint32_t i = 0; a[i] == b[i]; i++) {
		if (a[i] == '\0' && b[i] == '\0') {
			return 1;
		}
	}
	return 0;
}

void fillscr(unsigned char c) {
	for (uint32_t i = 0; i < 4000; i++) {
		vidptr[(i*2)+1] = (c*16) | (color & 0x0F);
	}
}

void setColor(unsigned char c) {
	color = (color & 0xF0) | c;
}

void setBkgColor(unsigned char c) {
	color = (color & 0x0F) | (c*16);
	trsp = (c == 0x10);
}

void hideCursor() {
	cursor(2000);
}

void updateCursor() {
	cursor((current_vga_pos/2));
}

void gotoxy(unsigned int x, unsigned int y) {
	current_vga_pos = ((y*80)+x)*2;
	ypos = y;
}

void nl() {
	gotoxy(0, ypos+1);
}

void _scroll() {
	for (uint16_t i = 80; i < 2000; i++) {
		vidptr[(i-80)*2] = vidptr[(i*2)];
		vidptr[((i-80)*2)+1] = vidptr[(i*2)+1];
		vidptr[(i*2)] = 0;
	}
	for (uint8_t i = 0; i < 80; i++) {
		gotoxy(0, 24);
		vidptr[(current_vga_pos+i)*2] = '\0';
	}
	if (current_vga_pos >= 160) {
		current_vga_pos -= 160;
	}
}

void scroll(uint8_t lines) {
	for (uint8_t i = 0; i < lines; i++) {
		_scroll();
	}
}

void printf(char *str) {
	unsigned int j = 0;
	while(str[j] != '\0') {
		while (current_vga_pos >= 4000) {
			scroll(1);
		}
		if (str[j] == '\n') {
			nl();
			j = j + 1;
		} else {
			vidptr[current_vga_pos] = str[j];
			vidptr[current_vga_pos+1] = (trsp)?((color&0x0F)|(vidptr[current_vga_pos+1]&0xF0)):(color);
			j = j + 1;
			current_vga_pos = current_vga_pos + 2;
			if ((current_vga_pos/2)%80 == 0) {
				ypos++;
			}
		}
	}
}

void putchar(char c) {
	while (current_vga_pos >= 4000) {
		scroll(1);
	}
	vidptr[current_vga_pos] = c;
	vidptr[current_vga_pos+1] = (trsp)?((color&0x0F)|(vidptr[current_vga_pos+1]&0xF0)):(color);
	current_vga_pos = current_vga_pos + 2;
	if ((current_vga_pos/2)%80 == 0) {
		ypos++;
	}
}

void printk(char *str) {
	unsigned int j = 0;
	while(str[j] != '\0') {
		while (current_vga_pos >= 4000) {
			scroll(1);
		}
		vidptr[current_vga_pos] = str[j];
		vidptr[current_vga_pos+1] = (trsp)?((color&0x0F)|(vidptr[current_vga_pos+1]&0xF0)):(color);
		j = j + 1;
		current_vga_pos = current_vga_pos + 2;
		if ((current_vga_pos/2)%80 == 0) {
			ypos++;
		}
	}
}

void dprintk(char *str) {
	unsigned int j = 0;
	while(str[j] != '\0') {
		vidptr[current_vga_pos] = str[j];
		vidptr[current_vga_pos+1] = (trsp)?((color&0x0F)|(vidptr[current_vga_pos+1]&0xF0)):(color);
		j = j + 1;
		current_vga_pos = current_vga_pos + 2;
		if ((current_vga_pos/2)%80 == 0) {
			ypos++;
		}
	}
}

char toupper(char inp) {
	if (inp >= 97 && inp <= 122) {
		return inp-32;
	} else {
		return inp;
	}
}

char tolower(char inp) {
	if (inp >= 65 && inp <= 90) {
		return inp+32;
	} else {
		return inp;
	}
}

void clrscr() {
	unsigned int j = 0;
	while(j < 80 * 25 * 2) {
		vidptr[j] = ' ';
		vidptr[j+1] = 0x0F; 		
		j = j + 2;
	}
	gotoxy(0, 0);
}

void noColor() {
	for (uint32_t i = 0; i < 4000; i++) {
		vidptr[(i*2)+1] = 0x0F;
	}
}

void printg(char *str, uint8_t x, uint8_t y, uint8_t posx, uint8_t nx) {
	unsigned int j = 0;
	unsigned int jx = 0;
	unsigned int jy = 0;
	while(str[j] != '\0') {
		while (current_vga_pos >= 4000) {
			scroll(1);
		}
		if (jy == 0) {
			gotoxy(x+jx, y+jy);
		} else {
			gotoxy(nx+jx, y+jy);
		}
		vidptr[current_vga_pos] = str[j];
		vidptr[current_vga_pos+1] = (trsp)?((color&0x0F)|(vidptr[current_vga_pos+1]&0xF0)):(color);
		j++;
		jx++;
		if (jx == posx) {
			jx = 0;
			jy++;
		}
	}
}

void okf(char *str) {
	uint8_t pcolor = color;
	setColor(2);
	printf(str);
	color = pcolor;
}

void errorf(char *str) {
	uint8_t pcolor = color;
	setColor(4);
	printf(str);
	color = pcolor;
}

void warnf(char *str) {
	uint8_t pcolor = color;
	setColor(14);
	printf(str);
	color = pcolor;
}

void memcpy(uint8_t *src, uint8_t *dest) {
	uint32_t i = 0;
	while (src[i] != (uint8_t)'\0') {
		dest[i] = src[i];
		i++;
	}
}
#endif