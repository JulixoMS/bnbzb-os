#ifndef __KMTTK
#define __KMTTK
#include "klib.h"
#include "kport.h"

uint8_t *prcptr = (uint8_t *)0x00002010;
uint8_t *prcind = (uint8_t *)0x00002000;
uint8_t *prcmax = (uint8_t *)0x00002001;

typedef struct process {
	uint32_t prc;
	uint8_t pid;
	uint8_t pdata;
} process;

process *initprc(uint8_t *paddr) {
	if (*prcmax == 0xFF) {
		return (process *)0;
	}
	process *p = malloc(48);
	p->prc = (uint32_t)(paddr);
	p->pid = *prcmax;
	p->pdata = 0x00;
	prcptr[(((uint32_t)p->pid)*4)+0] = ((p->prc >> 0) & 0xFF);
	prcptr[(((uint32_t)p->pid)*4)+1] = ((p->prc >> 8) & 0xFF);
	prcptr[(((uint32_t)p->pid)*4)+2] = ((p->prc >> 16) & 0xFF);
	prcptr[(((uint32_t)p->pid)*4)+3] = ((p->prc >> 24) & 0xFF);
	*prcmax++;
	return p;
}

void haltprc(process *p) {
	if (p->pid == prcmax-1) {
		prcptr[(((uint32_t)p->pid)*4)+0] = 0x00;
		prcptr[(((uint32_t)p->pid)*4)+1] = 0x00;
		prcptr[(((uint32_t)p->pid)*4)+2] = 0x00;
		prcptr[(((uint32_t)p->pid)*4)+3] = 0x00;
		*prcmax--;
		*prcind = 0;
		free(p);
		return;
	}
	prcmax--;
	for (uint8_t pid = p->pid; pid < *prcmax; pid++) {
		prcptr[(((uint32_t)pid)*4)+0] = prcptr[(((uint32_t)pid+1)*4)+0];
		prcptr[(((uint32_t)pid)*4)+1] = prcptr[(((uint32_t)pid+1)*4)+1];
		prcptr[(((uint32_t)pid)*4)+2] = prcptr[(((uint32_t)pid+1)*4)+2];
		prcptr[(((uint32_t)pid)*4)+3] = prcptr[(((uint32_t)pid+1)*4)+3];
	}
	prcptr[(((uint32_t)*prcmax)*4)+0] = 0x00;
	prcptr[(((uint32_t)*prcmax)*4)+1] = 0x00;
	prcptr[(((uint32_t)*prcmax)*4)+2] = 0x00;
	prcptr[(((uint32_t)*prcmax)*4)+3] = 0x00;
	*prcind = 0;
	free(p);
	return;
}

void resetprc(void) {
	*prcind = 0;
	return;
}

void forceprc(process *p) {
	*prcind = p->pid;
	callx(p->prc);
	return;
}

void initprclib(void) {
	*prcind = 0x00;
	*prcmax = 0x00;
	return;
}
#endif