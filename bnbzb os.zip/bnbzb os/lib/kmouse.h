#ifndef __KMOUSE
#define __KMOUSE

#include "klib.h"

uint16_t mouseX = 320;
uint16_t mouseY = 240;

uint16_t speedX = 1;
uint16_t speedY = 1;

int16_t offX = 0;
int16_t offY = 0;

uint8_t mwheel = 0;

uint32_t mpkg = 0;

uint8_t mread() {
	while(!(inb(0x64) & 1)) asm("pause");
	return inb(0x60);
}

uint8_t mcmd(uint8_t cmd) {
	outb(0x64, 0xD4);
	outb(0x60, cmd);
	uint8_t r = mread();
	if (r!=0xFA) {
		return r;
	}
	return 0;
}

void mreset(void) {
	outb(0x64, 0xD4);
	outb(0x60, 0xFF);
	while (mread()!=0xAA);
}

uint8_t mpacket(void) {
	uint8_t res = mcmd(0xEB);
	mpkg = 0x00000000;
	uint8_t inp = 0x00;
	inp = inb(0x60);
	mpkg = mpkg | (inp << 0);
	inp = mread();
	mpkg = mpkg | (inp << 8);
	inp = mread();
	mpkg = mpkg | (inp << 16);
	if (mwheel) {
		inp = mread();
		mpkg = mpkg | (inp << 24);
	}
	return res;
}

uint8_t minit(void) {
	mreset();
	return mcmd(0xF5);
}

void mupdt(void) {
	mpacket();
	uint16_t deltaX = (mpkg >> 8) & 0xFF;
	uint16_t deltaY = (mpkg >> 16) & 0xFF;
	uint8_t signdX = mpkg & 0x10;
	uint8_t signdY = mpkg & 0x20;
	deltaX /= speedX;
	deltaY /= speedY;
	if (signdX) {
		mouseX -= deltaX;
	} else {
		mouseX += deltaX;
	}
	if (signdY) {
		mouseY -= deltaY;
	} else {
		mouseY += deltaY;
	}
	if (mouseX >= 640) {
		mouseX = 639;
	} else if (mouseX < 0) {
		mouseX = 0;
	}
	if (mouseY >= 480) {
		mouseY = 479;
	} else if (mouseY < 0) {
		mouseY = 0;
	}
	mouseX += offX;
	mouseY += offY;
}

#endif