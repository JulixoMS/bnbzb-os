#ifndef __KYBRD
#define __KYBRD
#include "kport.h"
// Finally I did it!

#define ENTER (unsigned char)'\n'
#define ESCAPE (unsigned char)0x1B
#define BACKSPACE (unsigned char)0x08

unsigned char res = '\0';

unsigned char keyboard() {
	unsigned char ps2 = inb(0x64);
	if ((ps2 & 0x20) == 1) {
		return '\0';
	}
	if ((ps2 % 2) == 0) {
		return '\0';
	} else {
		unsigned char inp = inb(0x60);
		res = '\0';
		if (inp == 0x10) {
			res = 'Q';
		} else if (inp == 0x11) {
			res = 'W';
		} else if (inp == 0x12) {
			res = 'E';
		} else if (inp == 0x13) {
			res = 'R';
		} else if (inp == 0x14) {
			res = 'T';
		} else if (inp == 0x15) {
			res = 'Y';
		} else if (inp == 0x16) {
			res = 'U';
		} else if (inp == 0x17) {
			res = 'I';
		} else if (inp == 0x18) {
			res = 'O';
		} else if (inp == 0x19) {
			res = 'P';
		} else if (inp == 0x1E) {
			res = 'A';
		} else if (inp == 0x1F) {
			res = 'S';
		} else if (inp == 0x20) {
			res = 'D';
		} else if (inp == 0x21) {
			res = 'F';
		} else if (inp == 0x22) {
			res = 'G';
		} else if (inp == 0x23) {
			res = 'H';
		} else if (inp == 0x24) {
			res = 'J';
		} else if (inp == 0x25) {
			res = 'K';
		} else if (inp == 0x26) {
			res = 'L';
		} else if (inp == 0x2C) {
			res = 'Z';
		} else if (inp == 0x2D) {
			res = 'X';
		} else if (inp == 0x2E) {
			res = 'C';
		} else if (inp == 0x2F) {
			res = 'V';
		} else if (inp == 0x30) {
			res = 'B';
		} else if (inp == 0x31) {
			res = 'N';
		} else if (inp == 0x32) {
			res = 'M';
		} else if (inp == 0x33) {
			res = ',';
		} else if (inp == 0x34) {
			res = '.';
		} else if (inp == 0x35) {
			res = '-';
		} else if (inp == 0x1A) {
			res = '`';
		} else if (inp == 0x1B) {
			res = '+';
		} else if (inp == 0x1C) {
			res = ENTER;
		} else if (inp == 0x27) {
			res = '´';
		} else if (inp == 0x28) {
			res = '=';
		} else if (inp == 0x01) {
			res = ESCAPE;
		} else if (inp >= 0x02 && inp <= 0x0A) {
			res = (unsigned char)(inp+47);
		} else if (inp == 0x0B) {
			res = '0';
		} else if (inp == 0x0C) {
			res = '\'';
		} else if (inp == 0x0D) {
			res = '!';
		} else if (inp == 0x0E) {
			res = BACKSPACE;
		} else if (inp == 0x39) {
			res = ' ';
		} else if (inp == 0x3A) {
			res = 'm';
		}
	}
	return res;
}
#endif