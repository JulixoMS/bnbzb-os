#ifndef __KCOLOR
#define __KCOLOR
#include "klib.h"

//       TXT BKG
#define _050V050 (char)177
#define _025V075 (char)176
#define _075V025 (char)178
#define _100V000 (char)219
#define _000V100 (char)32

#define BLACK         0
#define BLUE          1
#define GREEN         2
#define CYAN          3
#define RED           4
#define MAGENTA       5
#define BROWN         6
#define LIGHT_GRAY    7
#define GRAY          8
#define LIGHT_BLUE    9
#define LIGHT_GREEN   10
#define LIGHT_CYAN    11
#define LIGHT_RED     12
#define LIGHT_MAGENTA 13
#define YELLOW        14
#define WHITE         15
#define TRANSPARENT   16

typedef uint16_t color_t;

char *ctt = " ";

// 16 bit colors

color_t encodeColor(uint8_t c1, uint8_t c2, uint8_t mode) {
	return ((mode & 0xFF) << 8) | ((c2 & 0x0F) << 4) | (c1 & 0x0F);
}

void setColorM(color_t color) {
	setColor(color & 0x0F);
	setBkgColor((color >> 4) & 0x0F);
	ctt[0] = (color >> 8) & 0xFF;
	printf(ctt);
}

void drawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, color_t c) {
	for (uint8_t i = x; i < x+w; i++) {
		for (uint8_t j = y; j < y+h; j++) {
			gotoxy(i, j);
			setColorM(c);
		}
	}
}
#endif