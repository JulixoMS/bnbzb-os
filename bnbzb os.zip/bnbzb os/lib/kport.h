#ifndef INCLUDE_IO_H
#define INCLUDE_IO_H

// 0x00002000: current multitasking process (0 - n-1)
// 0x00002001: number of multitasking processes (n)
// 0x00002010 - 0x00002FFF: multitasking process address

void outb(unsigned short port, unsigned char data);
unsigned char inb(unsigned short port);
void outw(unsigned short port, unsigned short data);
unsigned short inw(unsigned short port);
void outd(unsigned short port, unsigned int data);
unsigned int ind(unsigned short port);
void _asetfontmode(void);
void _aresetfontmode(void);
unsigned char _cmode(void);
void callx(unsigned long int adr);
void noop(void);
void clkwait(long long int ticks) {
	ticks>0?clkwait(ticks-5):noop();
}
void _gdt(unsigned int adr);
void _idt(unsigned int adr);
void _unlock(void);
void _hlt(void);
void _pmode(void);
void _rmode(void);
void _a20(void);
void _graphics(void);
void _yield(void);
void beep(void);
void mute(void);
void crashsys(void);

#endif
