#include "lib/kybrd.h"
#include "lib/klib.h"
#include "lib/kfunc.h"
#include "lib/kcolor.h"
#include "lib/kmouse.h"
#include "lib/kmttk.h"
#define MIN_ADDR 0x800000
#define SYS_REV "5/19"

// bnbzb OS
// Made by _julixo(Julio Meroño Sáez)
// Keep in mind that this is almost entirely programmed by a 12 years old boy(except the file malloc.h), so if you
// see any error or you want to suggest something, please send me an email(julixo2016company@gmail.com).
// All the OS is made in C and in NASM(Netwide Assembler). This file is the source code of the real OS that should
// be allocated in the hard drive of the computer with bnbzb OS. Because of not having the ATA drivers implemented,
// the OS is linked to the boot manager kernel.

// NOTE: The files that start with '_' are empty.

// BASIC IDEA:
// Protected mode OS, with a 'GUI' made with text(like DOSshell in text mode)
// Can generate sound, read mouse and keyboard, show text(obviously) and read/write to non-volatile memory storages
// Graphics: VGA 80x25 16-Colors(Up to 1024-Colors with tricks) with 8x16 text font
// Memory: Min. 8 MiB of RAM 

/*
IMAGE
    *((uint8_t *)(i+0)) = 0;
    *((uint8_t *)(i+1)) = 0;
    *((uint8_t *)(i+2)) = 0;
    *((uint8_t *)(i+3)) = 0;
    *((uint8_t *)(i+4)) = 255;
    *((uint8_t *)(i+5)) = 128;
    *((uint8_t *)(i+6)) = 160;
    *((uint8_t *)(i+7)) = 152;
    *((uint8_t *)(i+8)) = 142;
    *((uint8_t *)(i+9)) = 131;
    *((uint8_t *)(i+10)) = 129;
    *((uint8_t *)(i+11)) = 128;
    *((uint8_t *)(i+12)) = 128;
    *((uint8_t *)(i+13)) = 128;
    *((uint8_t *)(i+14)) = 128;
    *((uint8_t *)(i+15)) = 142;

    *((uint8_t *)(i+0)) = 248;
    *((uint8_t *)(i+1)) = 128;
    *((uint8_t *)(i+2)) = 128;
    *((uint8_t *)(i+3)) = 131;
    *((uint8_t *)(i+4)) = 158;
    *((uint8_t *)(i+5)) = 224;
    *((uint8_t *)(i+6)) = 200;
    *((uint8_t *)(i+7)) = 132;
    *((uint8_t *)(i+8)) = 128;
    *((uint8_t *)(i+9)) = 212;
    *((uint8_t *)(i+10)) = 128;
    *((uint8_t *)(i+11)) = 255;
    *((uint8_t *)(i+12)) = 0;
    *((uint8_t *)(i+13)) = 0;
    *((uint8_t *)(i+14)) = 0;
    *((uint8_t *)(i+15)) = 0;

    *((uint8_t *)(i+0)) = 0;
    *((uint8_t *)(i+1)) = 0;
    *((uint8_t *)(i+2)) = 0;
    *((uint8_t *)(i+3)) = 0;
    *((uint8_t *)(i+4)) = 255;
    *((uint8_t *)(i+5)) = 0;
    *((uint8_t *)(i+6)) = 0;
    *((uint8_t *)(i+7)) = 0;
    *((uint8_t *)(i+8)) = 0;
    *((uint8_t *)(i+9)) = 3;
    *((uint8_t *)(i+10)) = 204;
    *((uint8_t *)(i+11)) = 24;
    *((uint8_t *)(i+12)) = 48;
    *((uint8_t *)(i+13)) = 32;
    *((uint8_t *)(i+14)) = 64;
    *((uint8_t *)(i+15)) = 64;

    *((uint8_t *)(i+0)) = 64;
    *((uint8_t *)(i+1)) = 102;
    *((uint8_t *)(i+2)) = 61;
    *((uint8_t *)(i+3)) = 196;
    *((uint8_t *)(i+4)) = 16;
    *((uint8_t *)(i+5)) = 1;
    *((uint8_t *)(i+6)) = 148;
    *((uint8_t *)(i+7)) = 2;
    *((uint8_t *)(i+8)) = 144;
    *((uint8_t *)(i+9)) = 2;
    *((uint8_t *)(i+10)) = 0;
    *((uint8_t *)(i+11)) = 255;
    *((uint8_t *)(i+12)) = 0;
    *((uint8_t *)(i+13)) = 0;
    *((uint8_t *)(i+14)) = 0;
    *((uint8_t *)(i+15)) = 0;

    *((uint8_t *)(i+0)) = 0;
    *((uint8_t *)(i+1)) = 0;
    *((uint8_t *)(i+2)) = 0;
    *((uint8_t *)(i+3)) = 0;
    *((uint8_t *)(i+4)) = 255;
    *((uint8_t *)(i+5)) = 128;
    *((uint8_t *)(i+6)) = 128;
    *((uint8_t *)(i+7)) = 128;
    *((uint8_t *)(i+8)) = 1;
    *((uint8_t *)(i+9)) = 195;
    *((uint8_t *)(i+10)) = 56;
    *((uint8_t *)(i+11)) = 12;
    *((uint8_t *)(i+12)) = 2;
    *((uint8_t *)(i+13)) = 2;
    *((uint8_t *)(i+14)) = 2;
    *((uint8_t *)(i+15)) = 2;

    *((uint8_t *)(i+0)) = 2;
    *((uint8_t *)(i+1)) = 2;
    *((uint8_t *)(i+2)) = 246;
    *((uint8_t *)(i+3)) = 47;
    *((uint8_t *)(i+4)) = 0;
    *((uint8_t *)(i+5)) = 137;
    *((uint8_t *)(i+6)) = 38;
    *((uint8_t *)(i+7)) = 0;
    *((uint8_t *)(i+8)) = 73;
    *((uint8_t *)(i+9)) = 18;
    *((uint8_t *)(i+10)) = 0;
    *((uint8_t *)(i+11)) = 255;
    *((uint8_t *)(i+12)) = 0;
    *((uint8_t *)(i+13)) = 0;
    *((uint8_t *)(i+14)) = 0;
    *((uint8_t *)(i+15)) = 0;

    *((uint8_t *)(i+0)) = 0;
    *((uint8_t *)(i+1)) = 0;
    *((uint8_t *)(i+2)) = 0;
    *((uint8_t *)(i+3)) = 0;
    *((uint8_t *)(i+4)) = 255;
    *((uint8_t *)(i+5)) = 49;
    *((uint8_t *)(i+6)) = 33;
    *((uint8_t *)(i+7)) = 193;
    *((uint8_t *)(i+8)) = 129;
    *((uint8_t *)(i+9)) = 1;
    *((uint8_t *)(i+10)) = 1;
    *((uint8_t *)(i+11)) = 1;
    *((uint8_t *)(i+12)) = 1;
    *((uint8_t *)(i+13)) = 1;
    *((uint8_t *)(i+14)) = 1;
    *((uint8_t *)(i+15)) = 249;

    *((uint8_t *)(i+0)) = 7;
    *((uint8_t *)(i+1)) = 1;
    *((uint8_t *)(i+2)) = 1;
    *((uint8_t *)(i+3)) = 1;
    *((uint8_t *)(i+4)) = 253;
    *((uint8_t *)(i+5)) = 3;
    *((uint8_t *)(i+6)) = 43;
    *((uint8_t *)(i+7)) = 1;
    *((uint8_t *)(i+8)) = 73;
    *((uint8_t *)(i+9)) = 65;
    *((uint8_t *)(i+10)) = 19;
    *((uint8_t *)(i+11)) = 255;
    *((uint8_t *)(i+12)) = 0;
    *((uint8_t *)(i+13)) = 0;
    *((uint8_t *)(i+14)) = 0;
    *((uint8_t *)(i+15)) = 0;


*/

#define _16X16 0
#define _16X32 1
#define _32X32 2

process *p1;
process *p2;
process *p3;
process *os;

void func1(void) {
	gotoxy(10, 10);
	setColor(WHITE);
	setBkgColor(BLACK);
	printf("This is the first task! ");
	printf(itoa(p1->pdata, 16));
	printf("\n");
	p1->pdata++;
	//_yield();
	forceprc(p2);
}

void func2(void) {
	gotoxy(10, 11);
	setColor(WHITE);
	setBkgColor(BLACK);
	printf("This is the second task! ");
	printf(itoa(p2->pdata, 16));
	printf("\n");
	p2->pdata++;
	//_yield();
	forceprc(p3);
}

void func3(void) {
	gotoxy(10, 12);
	setColor(WHITE);
	setBkgColor(BLACK);
	printf("This is the third task! ");
	printf(itoa(p3->pdata, 16));
	printf("\n");
	p3->pdata++;
	//_yield();
	forceprc(os);
}

void printsymb(uint8_t symb, uint8_t mode, uint8_t x, uint8_t y) {
	if (mode == _16X16) {
		gotoxy(x, y);
		putchar(symb);
		putchar(symb+1);
	} else if (mode == _16X32) {
		for (uint8_t i = 0; i < 2; i++) {
			for (uint8_t j = 0; j < 2; j++) {
				gotoxy(x+i, y+j);
				putchar(symb+(j+(i*2)));
			}
		}
	} else if (mode == _32X32) {
		for (uint8_t i = 0; i < 4; i++) {
			for (uint8_t j = 0; j < 2; j++) {
				gotoxy(x+i, y+j);
				putchar(symb+(j+(i*2)));
			}
		}
	}
}

void _setfontmode(void) {
	outw(0x0100, 0x3C4); // do a synch. reset 
	outw(0x0402, 0x3C4); // write Plane 2 only 
	outw(0x0704, 0x3C4); // sequential access 
	outw(0x0300, 0x3C4); // end the reset 
	outw(0x0204, 0x3CE); // read Plane 2 only 
	outw(0x0005, 0x3CE); // disable odd/even 
	outw(0x0006, 0x3CE); // VRAM at 0xA0000 
}

void _resetfontmode(void) {
	outw(0x0100, 0x3C4); // do a synch. reset 
	outw(0x0302, 0x3C4); // write Planes 0 & 1 
	outw(0x0304, 0x3C4); // odd/even access 
	outw(0x0300, 0x3C4); // end the reset 
	outw(0x0004, 0x3CE); // restore to ‘default’ 
	outw(0x1005, 0x3CE); // resume odd/even 
	outw(0x0E06, 0x3CE); // VRAM at 0xB8000
}

uint8_t state = 0;
uint8_t use_mouse = 1;
uint8_t *status = (uint8_t*)0x3000;

void loop(void) {
	for (uint64_t i = 0; i < 0xFFFFFF; i++) {} // Relax CPU and memory
	drawRect(0, 0, 80, 24, encodeColor(LIGHT_BLUE, LIGHT_BLUE, _000V100));
	setColor(WHITE);
	setBkgColor(TRANSPARENT);
	printsymb(128, _32X32, 9, 2);
	gotoxy(4, 4);
	printf("MYFILEf1.XXX");
	printsymb(136, _32X32, 29, 2);
	gotoxy(24, 4);
	printf("NEWDIR02");
	printsymb(144, _32X32, 49, 2);
	gotoxy(44, 4);
	printf("IMPORTA~.TXT");
	gotoxy(mouseX/(640/80), mouseY/(480/24));
	printk("\1");
	for (uint8_t x = 0; x < 80; x++) {
		gotoxy(x, 24);
		setColor(BLACK);
		setBkgColor(LIGHT_GRAY);
		printk(" ");
		gotoxy(x, 0);
		setColor(BLACK);
		setBkgColor(LIGHT_GRAY);
		printk(" ");
	}
	gotoxy(1, 24);
	setColor(BLACK);
	printf(status);
	if (use_mouse) {
		mupdt();
	} else {
		// Keyboard???
	}
	updateScr();
	//_yield();
	forceprc(p1);
}

void main(void) {
	initprclib();
	os = initprc(&loop);
	p1 = initprc(&func1);
	p2 = initprc(&func2);
	p3 = initprc(&func3);
	_asetfontmode();
	uint8_t j = 0;
	for (uint32_t i = 0xA0000; i < 0xAFFFF; i += 0x20) {
		if (j == 1) {
			*((uint8_t *)(i+0)) = 128;
			*((uint8_t *)(i+1)) = 192;
			*((uint8_t *)(i+2)) = 192;
			*((uint8_t *)(i+3)) = 224;
			*((uint8_t *)(i+4)) = 240;
			*((uint8_t *)(i+5)) = 240;
			*((uint8_t *)(i+6)) = 248;
			*((uint8_t *)(i+7)) = 252;
			*((uint8_t *)(i+8)) = 252;
			*((uint8_t *)(i+9)) = 240;
			*((uint8_t *)(i+10)) = 144;
			*((uint8_t *)(i+11)) = 8;
			*((uint8_t *)(i+12)) = 8;
			*((uint8_t *)(i+13)) = 4;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 0;
		} else if (j == 128) {
			*((uint8_t *)(i+0)) = 15;
			*((uint8_t *)(i+1)) = 8;
			*((uint8_t *)(i+2)) = 8;
			*((uint8_t *)(i+3)) = 8;
			*((uint8_t *)(i+4)) = 8;
			*((uint8_t *)(i+5)) = 8;
			*((uint8_t *)(i+6)) = 8;
			*((uint8_t *)(i+7)) = 8;
			*((uint8_t *)(i+8)) = 8;
			*((uint8_t *)(i+9)) = 8;
			*((uint8_t *)(i+10)) = 8;
			*((uint8_t *)(i+11)) = 8;
			*((uint8_t *)(i+12)) = 8;
			*((uint8_t *)(i+13)) = 8;
			*((uint8_t *)(i+14)) = 8;
			*((uint8_t *)(i+15)) = 8;
		} else if (j == 129) {
			*((uint8_t *)(i+0)) = 8;
			*((uint8_t *)(i+1)) = 8;
			*((uint8_t *)(i+2)) = 8;
			*((uint8_t *)(i+3)) = 8;
			*((uint8_t *)(i+4)) = 8;
			*((uint8_t *)(i+5)) = 8;
			*((uint8_t *)(i+6)) = 8;
			*((uint8_t *)(i+7)) = 8;
			*((uint8_t *)(i+8)) = 8;
			*((uint8_t *)(i+9)) = 8;
			*((uint8_t *)(i+10)) = 8;
			*((uint8_t *)(i+11)) = 8;
			*((uint8_t *)(i+12)) = 8;
			*((uint8_t *)(i+13)) = 8;
			*((uint8_t *)(i+14)) = 8;
			*((uint8_t *)(i+15)) = 15;
		} else if (j == 130) {
			*((uint8_t *)(i+0)) = 255;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 0;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 0;
			*((uint8_t *)(i+6)) = 0;
			*((uint8_t *)(i+7)) = 0;
			*((uint8_t *)(i+8)) = 0;
			*((uint8_t *)(i+9)) = 0;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 0;
			*((uint8_t *)(i+12)) = 0;
			*((uint8_t *)(i+13)) = 0;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 0;
		} else if (j == 131) {
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 0;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 0;
			*((uint8_t *)(i+6)) = 0;
			*((uint8_t *)(i+7)) = 0;
			*((uint8_t *)(i+8)) = 0;
			*((uint8_t *)(i+9)) = 0;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 0;
			*((uint8_t *)(i+12)) = 0;
			*((uint8_t *)(i+13)) = 0;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 255;
		} else if (j == 132) {
			*((uint8_t *)(i+0)) = 240;
			*((uint8_t *)(i+1)) = 24;
			*((uint8_t *)(i+2)) = 20;
			*((uint8_t *)(i+3)) = 18;
			*((uint8_t *)(i+4)) = 17;
			*((uint8_t *)(i+5)) = 16;
			*((uint8_t *)(i+6)) = 16;
			*((uint8_t *)(i+7)) = 16;
			*((uint8_t *)(i+8)) = 31;
			*((uint8_t *)(i+9)) = 0;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 0;
			*((uint8_t *)(i+12)) = 0;
			*((uint8_t *)(i+13)) = 0;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 0;
		} else if (j == 133) {
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 0;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 0;
			*((uint8_t *)(i+6)) = 0;
			*((uint8_t *)(i+7)) = 0;
			*((uint8_t *)(i+8)) = 0;
			*((uint8_t *)(i+9)) = 0;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 0;
			*((uint8_t *)(i+12)) = 0;
			*((uint8_t *)(i+13)) = 0;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 255;
		} else if (j == 134) {
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 0;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 128;
			*((uint8_t *)(i+6)) = 64;
			*((uint8_t *)(i+7)) = 32;
			*((uint8_t *)(i+8)) = 240;
			*((uint8_t *)(i+9)) = 16;
			*((uint8_t *)(i+10)) = 16;
			*((uint8_t *)(i+11)) = 16;
			*((uint8_t *)(i+12)) = 16;
			*((uint8_t *)(i+13)) = 16;
			*((uint8_t *)(i+14)) = 16;
			*((uint8_t *)(i+15)) = 16;
		} else if (j == 135) {
			*((uint8_t *)(i+0)) = 16;
			*((uint8_t *)(i+1)) = 16;
			*((uint8_t *)(i+2)) = 16;
			*((uint8_t *)(i+3)) = 16;
			*((uint8_t *)(i+4)) = 16;
			*((uint8_t *)(i+5)) = 16;
			*((uint8_t *)(i+6)) = 16;
			*((uint8_t *)(i+7)) = 16;
			*((uint8_t *)(i+8)) = 16;
			*((uint8_t *)(i+9)) = 16;
			*((uint8_t *)(i+10)) = 16;
			*((uint8_t *)(i+11)) = 16;
			*((uint8_t *)(i+12)) = 16;
			*((uint8_t *)(i+13)) = 16;
			*((uint8_t *)(i+14)) = 16;
			*((uint8_t *)(i+15)) = 240;
		} else if (j == 136) { //
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 0;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 0;
			*((uint8_t *)(i+6)) = 0;
			*((uint8_t *)(i+7)) = 0;
			*((uint8_t *)(i+8)) = 0;
			*((uint8_t *)(i+9)) = 0;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 0;
			*((uint8_t *)(i+12)) = 255;
			*((uint8_t *)(i+13)) = 128;
			*((uint8_t *)(i+14)) = 128;
			*((uint8_t *)(i+15)) = 128;
		} else if (j == 137) { //
			*((uint8_t *)(i+0)) = 128;
			*((uint8_t *)(i+1)) = 143;
			*((uint8_t *)(i+2)) = 136;
			*((uint8_t *)(i+3)) = 136;
			*((uint8_t *)(i+4)) = 136;
			*((uint8_t *)(i+5)) = 144;
			*((uint8_t *)(i+6)) = 144;
			*((uint8_t *)(i+7)) = 144;
			*((uint8_t *)(i+8)) = 160;
			*((uint8_t *)(i+9)) = 160;
			*((uint8_t *)(i+10)) = 160;
			*((uint8_t *)(i+11)) = 192;
			*((uint8_t *)(i+12)) = 192;
			*((uint8_t *)(i+13)) = 192;
			*((uint8_t *)(i+14)) = 128;
			*((uint8_t *)(i+15)) = 255;
		} else if (j == 138) { //
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 0;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 0;
			*((uint8_t *)(i+6)) = 0;
			*((uint8_t *)(i+7)) = 0;
			*((uint8_t *)(i+8)) = 0;
			*((uint8_t *)(i+9)) = 0;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 0;
			*((uint8_t *)(i+12)) = 255;
			*((uint8_t *)(i+13)) = 0;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 0;
		} else if (j == 139) { //
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 255;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 0;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 0;
			*((uint8_t *)(i+6)) = 0;
			*((uint8_t *)(i+7)) = 0;
			*((uint8_t *)(i+8)) = 0;
			*((uint8_t *)(i+9)) = 0;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 0;
			*((uint8_t *)(i+12)) = 0;
			*((uint8_t *)(i+13)) = 0;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 255;
		} else if (j == 140) { //
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 0;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 0;
			*((uint8_t *)(i+6)) = 0;
			*((uint8_t *)(i+7)) = 0;
			*((uint8_t *)(i+8)) = 15;
			*((uint8_t *)(i+9)) = 8;
			*((uint8_t *)(i+10)) = 8;
			*((uint8_t *)(i+11)) = 8;
			*((uint8_t *)(i+12)) = 255;
			*((uint8_t *)(i+13)) = 0;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 0;
		} else if (j == 141) { //
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 255;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 0;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 0;
			*((uint8_t *)(i+6)) = 0;
			*((uint8_t *)(i+7)) = 0;
			*((uint8_t *)(i+8)) = 0;
			*((uint8_t *)(i+9)) = 0;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 0;
			*((uint8_t *)(i+12)) = 0;
			*((uint8_t *)(i+13)) = 0;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 255;
		} else if (j == 142) { //
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 0;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 0;
			*((uint8_t *)(i+6)) = 0;
			*((uint8_t *)(i+7)) = 0;
			*((uint8_t *)(i+8)) = 240;
			*((uint8_t *)(i+9)) = 16;
			*((uint8_t *)(i+10)) = 16;
			*((uint8_t *)(i+11)) = 16;
			*((uint8_t *)(i+12)) = 240;
			*((uint8_t *)(i+13)) = 16;
			*((uint8_t *)(i+14)) = 16;
			*((uint8_t *)(i+15)) = 16;
		} else if (j == 143) { //
			*((uint8_t *)(i+0)) = 16;
			*((uint8_t *)(i+1)) = 254;
			*((uint8_t *)(i+2)) = 2;
			*((uint8_t *)(i+3)) = 2;
			*((uint8_t *)(i+4)) = 2;
			*((uint8_t *)(i+5)) = 4;
			*((uint8_t *)(i+6)) = 4;
			*((uint8_t *)(i+7)) = 4;
			*((uint8_t *)(i+8)) = 8;
			*((uint8_t *)(i+9)) = 8;
			*((uint8_t *)(i+10)) = 8;
			*((uint8_t *)(i+11)) = 16;
			*((uint8_t *)(i+12)) = 16;
			*((uint8_t *)(i+13)) = 16;
			*((uint8_t *)(i+14)) = 32;
			*((uint8_t *)(i+15)) = 224;
		} else if (j == 144) {
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 5;
			*((uint8_t *)(i+4)) = 10;
			*((uint8_t *)(i+5)) = 11;
			*((uint8_t *)(i+6)) = 6;
			*((uint8_t *)(i+7)) = 3;
			*((uint8_t *)(i+8)) = 2;
			*((uint8_t *)(i+9)) = 2;
			*((uint8_t *)(i+10)) = 2;
			*((uint8_t *)(i+11)) = 2;
			*((uint8_t *)(i+12)) = 2;
			*((uint8_t *)(i+13)) = 2;
			*((uint8_t *)(i+14)) = 2;
			*((uint8_t *)(i+15)) = 2;
		} else if (j == 145) {
			*((uint8_t *)(i+0)) = 2;
			*((uint8_t *)(i+1)) = 2;
			*((uint8_t *)(i+2)) = 2;
			*((uint8_t *)(i+3)) = 2;
			*((uint8_t *)(i+4)) = 2;
			*((uint8_t *)(i+5)) = 2;
			*((uint8_t *)(i+6)) = 2;
			*((uint8_t *)(i+7)) = 2;
			*((uint8_t *)(i+8)) = 2;
			*((uint8_t *)(i+9)) = 2;
			*((uint8_t *)(i+10)) = 2;
			*((uint8_t *)(i+11)) = 2;
			*((uint8_t *)(i+12)) = 2;
			*((uint8_t *)(i+13)) = 2;
			*((uint8_t *)(i+14)) = 2;
			*((uint8_t *)(i+15)) = 3;
		} else if (j == 146) {
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 85;
			*((uint8_t *)(i+4)) = 170;
			*((uint8_t *)(i+5)) = 255;
			*((uint8_t *)(i+6)) = 170;
			*((uint8_t *)(i+7)) = 85;
			*((uint8_t *)(i+8)) = 0;
			*((uint8_t *)(i+9)) = 255;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 254;
			*((uint8_t *)(i+12)) = 0;
			*((uint8_t *)(i+13)) = 255;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 240;
		} else if (j == 147) {
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 255;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 255;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 255;
			*((uint8_t *)(i+6)) = 0;
			*((uint8_t *)(i+7)) = 255;
			*((uint8_t *)(i+8)) = 0;
			*((uint8_t *)(i+9)) = 255;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 240;
			*((uint8_t *)(i+12)) = 0;
			*((uint8_t *)(i+13)) = 0;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 255;
		} else if (j == 148) {
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 85;
			*((uint8_t *)(i+4)) = 170;
			*((uint8_t *)(i+5)) = 255;
			*((uint8_t *)(i+6)) = 170;
			*((uint8_t *)(i+7)) = 85;
			*((uint8_t *)(i+8)) = 0;
			*((uint8_t *)(i+9)) = 255;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 254;
			*((uint8_t *)(i+12)) = 0;
			*((uint8_t *)(i+13)) = 255;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 240;
		} else if (j == 149) {
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 224;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 252;
			*((uint8_t *)(i+4)) = 0;
			*((uint8_t *)(i+5)) = 0;
			*((uint8_t *)(i+6)) = 0;
			*((uint8_t *)(i+7)) = 224;
			*((uint8_t *)(i+8)) = 0;
			*((uint8_t *)(i+9)) = 192;
			*((uint8_t *)(i+10)) = 0;
			*((uint8_t *)(i+11)) = 0;
			*((uint8_t *)(i+12)) = 0;
			*((uint8_t *)(i+13)) = 0;
			*((uint8_t *)(i+14)) = 0;
			*((uint8_t *)(i+15)) = 255;
		} else if (j == 150) {
			*((uint8_t *)(i+0)) = 0;
			*((uint8_t *)(i+1)) = 0;
			*((uint8_t *)(i+2)) = 0;
			*((uint8_t *)(i+3)) = 64;
			*((uint8_t *)(i+4)) = 160;
			*((uint8_t *)(i+5)) = 224;
			*((uint8_t *)(i+6)) = 224;
			*((uint8_t *)(i+7)) = 64;
			*((uint8_t *)(i+8)) = 64;
			*((uint8_t *)(i+9)) = 64;
			*((uint8_t *)(i+10)) = 64;
			*((uint8_t *)(i+11)) = 64;
			*((uint8_t *)(i+12)) = 64;
			*((uint8_t *)(i+13)) = 64;
			*((uint8_t *)(i+14)) = 64;
			*((uint8_t *)(i+15)) = 64;
		} else if (j == 151) {
			*((uint8_t *)(i+0)) = 64;
			*((uint8_t *)(i+1)) = 64;
			*((uint8_t *)(i+2)) = 64;
			*((uint8_t *)(i+3)) = 64;
			*((uint8_t *)(i+4)) = 64;
			*((uint8_t *)(i+5)) = 64;
			*((uint8_t *)(i+6)) = 64;
			*((uint8_t *)(i+7)) = 64;
			*((uint8_t *)(i+8)) = 64;
			*((uint8_t *)(i+9)) = 64;
			*((uint8_t *)(i+10)) = 64;
			*((uint8_t *)(i+11)) = 64;
			*((uint8_t *)(i+12)) = 64;
			*((uint8_t *)(i+13)) = 64;
			*((uint8_t *)(i+14)) = 64;
			*((uint8_t *)(i+15)) = 192;
		} else if (j == 152) {

		} else if (j == 153) {

		} else if (j == 154) {
			
		} else if (j == 155) {
			
		} else if (j == 156) {
			
		} else if (j == 157) {
			
		} else if (j == 150) {
			
		} else if (j == 151) {
			
		}
		j++;
	}
	_aresetfontmode();
	hideCursor();
	//setScrMode(PASIVE);
	memcpy("bnbzb OS", status);
	//_yield();
	forceprc(os);
	return;
}

void _main(void) {
	clrscr();
	gotoxy(0, 0);
	setColor(15);
	main();
	_hlt();
	return;
}