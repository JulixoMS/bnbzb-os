#include "lib/kybrd.h"
#include "lib/klib.h"
#include "lib/kfunc.h"
#include "main.c" // Comment this line when ATA implemented

typedef struct GDT {
	uint32_t limit;
	uint32_t base;
	uint8_t type;
} GDT;

void _mktable(uint8_t *target, GDT source) {
	if ((source.limit > 65536) && ((source.limit & 0xFFF) != 0xFFF)) {
		errorf("[ERROR]\n");
		_hlt();
	}
	if (source.limit > 65536) {
		source.limit = source.limit >> 12;
		target[6] = 0xC0;
	} else {
		target[6] = 0x40;
	}
	target[0] = source.limit & 0xFF;
	target[1] = (source.limit >> 8) & 0xFF;
	target[6] |= (source.limit >> 16) & 0xF;
	target[2] = source.base & 0xFF;
	target[3] = (source.base >> 8) & 0xFF;
	target[4] = (source.base >> 16) & 0xFF;
	target[7] = (source.base >> 24) & 0xFF;
	target[5] = source.type;
}

GDT gdtentry(uint32_t base, uint32_t limit, uint8_t type) {
	GDT gentry;
	gentry.base = base;
	gentry.limit = limit;
	gentry.type = type;
}

void kmain(void) {
	_unlock();
	clrscr();
	gotoxy(0, 0);
	setColor(15);
	hideCursor();
	printf("bnbzb OS r");
	printf(SYS_REV);
	printf("\nChecking hardware...\n");
	printf("Making Global Descriptor Table   ");
	GDT *table = malloc(sizeof(GDT)*4);
	table[0] = gdtentry(0, 0, 0);
	table[1] = gdtentry(0, 0xffffffff, 0x9A);
	table[2] = gdtentry(0, 0xffffffff, 0x92);
	table[3] = gdtentry(0/*&myTss*/, 0/*sizeof(myTss)*/, 0x89); // No TSS :(
	for (int i = 0; i < 4; i++) {
		_mktable(0x0800 + (sizeof(GDT)*i), table[i]);
	}
	_gdt(0x00000800);
	okf("[ OK  ]\n");
	printf("Unlocking A20 Line               ");
	_a20();
	okf("[ OK  ]\n");
	_pmode(); // Protected mode!!!
	int m = _cmode(); // Check mode
	printf("CPU Control Register cr0 change  ");
	if (m%2 == 0) {
		errorf("[ERROR]\n");
		_hlt();
	} else {
		okf("[ OK  ]\n");
	}
	printf("Protected mode(32 bit) enabled   ");
	*((unsigned char *)0x100000) = 0xAA;
	*((unsigned char *)0x0) = 0x00;
	if (*((unsigned char *)0x100000) != 0xAA) {
		errorf("[ERROR]\n");
		_hlt();
	} else {
		okf("[ OK  ]\n");
	}
	printf("Mouse port enabled               ");
	uint8_t n = minit();
	if (minit()) {
		warnf("[WARN ]\n");
		use_mouse = 0;
	} else {
		okf("[ OK  ]\n");
		printf("Use mouse or keyboard arrows(m/k)? ");
		updateCursor();
		uint8_t key = keyboard();
		while (key != 'M' && key != 'K') {
			key = keyboard();
		}
		use_mouse = (key=='M');
		printf(use_mouse?"m":"k");
		printf("\n");
	}
	if (use_mouse) {
		printf("To calibrate the mouse, please don't move the mouse and press ENTER.\n");
		uint8_t key = keyboard();
		while (key != ENTER) {
			uint16_t pmx = mouseX;
			uint16_t pmy = mouseY;
			key = keyboard();
			mupdt();
			offX = ((int16_t)(pmx)) - ((int16_t)(mouseX));
			offY = ((int16_t)(pmy)) - ((int16_t)(mouseY));
		}
	}
	printf("Minimal 8 MiB of RAM required    ");
	*((unsigned char *)MIN_ADDR) = 0x23;
	if (*((unsigned char *)MIN_ADDR) == 0x23) {
		okf("[ OK  ]\n");
	} else {
		errorf("[ERROR]\n");
		_hlt();
	}
	printf("When RAM checking finished, the computer will need to be restarted.\n");
	printf("Check RAM size(y/n)? ");
	updateCursor();
	uint8_t chk_ram = 0;
	uint8_t key = keyboard();
	while (key != 'Y' && key != 'N') {
		key = keyboard();
	}
	chk_ram = (key=='Y');
	printf(chk_ram?"y":"n");
	printf("\n");
	hideCursor();
	if (chk_ram) {
		printf("Checking RAM size...             ");
		okf("[");
		unsigned int cpos = current_vga_pos;
		uint8_t cnt = 1;
		uint8_t pval = 0;
		uint64_t ram = MIN_ADDR;
		while (cnt) {
			current_vga_pos = cpos;
			okf(itoa((ram+1)/0x100000, 10));
			okf(" MiB]");
			pval = *((unsigned char *)ram);
			*((unsigned char *)ram) = 0x23;
			if (*((unsigned char *)ram) == 0x23) {
				*((unsigned char *)ram) = pval;
				ram += 0x100000;
			} else {
				cnt = 0;
			}
		}
		printf("\nPlease, restart the computer.\n");
	}
	printf("Hardware checked. Starting OS...\n\n");
	updateCursor();
	for (uint64_t i = 0; i < 0xFFFFFF; i++) {} // Relax CPU and memory
	// ATA initialization and OS startup
	// Because of NOT having the ATA driver(to write/read files into the hard drive) code programmed, I'm currently
	// linking the OS and the bootloader kernel(this) as an unique file.
	_main(); // Starts the OS. When ATA implemented, comment this line and the line that includes the file "src/main.c".
	while (1);
	return;
}
